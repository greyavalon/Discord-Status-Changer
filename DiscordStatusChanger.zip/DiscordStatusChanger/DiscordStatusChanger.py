import time
import requests
import msvcrt
import os
import subprocess

url = "https://discord.com/api/v8/users/@me/settings"
status_file = "status.txt"
token_file = "token.txt"
delay_file = "delay.txt"

def get_token():
    if not os.path.exists(token_file):
        with open(token_file, 'w') as f:
            pass  
        token = input("Enter your Discord token: ").strip()
        with open(token_file, 'w') as f:
            f.write(token)
    else:
        with open(token_file, 'r') as f:
            token = f.read().strip()
    return token

def ChangeStatus(token, message):
    header = {
        "authorization": token
    }

    jsonData = {
        "status": "online",
        "custom_status": {
            "text": message
        }
    }

    requests.patch(url, headers=header, json=jsonData)

def ClearStatus(token):
    header = {
        "authorization": token
    }

    jsonData = {
        "status": "online",
        "custom_status": {
            "text": ""
        }
    }

    requests.patch(url, headers=header, json=jsonData)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def read_status_file():
    if not os.path.exists(status_file):
        clear_screen()
        print(f"Error: {status_file} not found.")
        print("Please restart the script and press 'E' to create and edit a new status.txt file.")
        input("\nPress Enter to exit...")
        exit()
    with open(status_file, 'r') as f:
        lines = f.readlines()
    return lines

def read_delay():
    try:
        with open(delay_file, 'r') as f:
            delay = float(f.read())
            return delay
    except FileNotFoundError:
        return 1.5
    except ValueError:
        return 1.5

def save_delay(delay):
    with open(delay_file, 'w') as f:
        f.write(str(delay))

def prompt_for_delay():
    while True:
        clear_screen()
        print("Enter new delay (in seconds):")
        delay_input = input("Delay: ")
        try:
            delay_value = float(delay_input)
            return delay_value
        except ValueError:
            print("Invalid input. Please enter a valid number.")
            input("Press Enter to try again...")

def main():
    token = get_token()
    running = False
    delay = read_delay()
    clear_screen()
    print('Discord Status Changer')
    print("Press R to start changing status, X to stop, C to close, E to edit status.txt, D to change delay.")
    print(f"Current delay: {delay} seconds.")

    while True:
        if msvcrt.kbhit():
            key = msvcrt.getch().decode('utf-8').lower()
            if key == 'r' and not running:
                clear_screen()
                print("Starting to change status...")
                running = True
            elif key == 'x' and running:
                clear_screen()
                print("Stopping status changes...")
                running = False
                clear_screen()
                print('Discord Status Changer')
                print("Press R to start changing status, X to stop, C to close, E to edit status.txt, D to change delay.")
                print(f"Current delay: {delay} seconds.")
            elif key == 'c':
                clear_screen()
                print("Are you sure you want to close? (Y/N)")
                confirmation = msvcrt.getch().decode('utf-8').lower()
                if confirmation == 'y':
                    print("Closing...")
                    break
                elif confirmation == 'n':
                    clear_screen()
                    print("Discord Status Changer")
                    print("Press R to start changing status, X to stop, C to close, E to edit status.txt, D to change delay.")
                    print(f"Current delay: {delay} seconds.")
            elif key == 'e':
                clear_screen()
                if not os.path.exists(status_file):
                    print(f"{status_file} not found. Creating a new one...")
                    with open(status_file, 'w') as f:
                        f.write("Enter your custom statuses here, one per line.\n")
                print("Opening status.txt for editing...")
                subprocess.run([r'notepad', status_file])
                clear_screen()
                print("Discord Status Changer")
                print("Press R to start changing status, X to stop, C to close, E to edit status.txt, D to change delay.")
                print(f"Current delay: {delay} seconds.")
            elif key == 'd':
                new_delay = prompt_for_delay()
                save_delay(new_delay)
                clear_screen()
                print(f"New delay set to {new_delay} seconds.")
                time.sleep(3)
                delay = new_delay
                clear_screen()
                print("Discord Status Changer")
                print("Press R to start changing status, X to stop, C to close, E to edit status.txt, D to change delay.")
                print(f"Current delay: {delay} seconds.")

        if running:
            lines = read_status_file()
            for line in lines:
                clear_screen()
                print("Active")
                print("X to stop.")
                print(f"Current delay: {delay} seconds.")
                ChangeStatus(token, line.strip())
                time.sleep(delay)

                if msvcrt.kbhit():
                    key = msvcrt.getch().decode('utf-8').lower()
                    if key == 'x':
                        clear_screen()
                        print("Stopping status changes...")
                        running = False
                        time.sleep(1)
                        clear_screen()
                        print("Discord Status Changer")
                        print("Press R to start changing status, X to stop, C to close, E to edit status.txt, D to change delay.")
                        print(f"Current delay: {delay} seconds.")
                        ClearStatus(token)
                        break

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("\nAn error occurred:")
        print(e)
        input("\nPress Enter to exit...")
