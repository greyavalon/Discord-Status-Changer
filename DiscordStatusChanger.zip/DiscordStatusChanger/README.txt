Thank you for downloading Open-Source Discord Status Changer :))

To set up the script, you'll need Python installed on your PC.
You can do so by going to Microsoft Store and installing Python 3.12.

Once done, simply open Setup.bat and simply enter your token (Open discord web and use inspect, go to Application and LocalStorage, filter "token" and click the device button at the top and you should see your token. THIS IS ONLY SAVED ON YOUR COMPUTER!!)

Once you've pasted your token, click E to create the status text file. Each line in there is a status.

If there are any issues, feel free to add my discord (greyavalon) and throw me a DM. I'll help the best I can ^^

Thank you for downloading!!
